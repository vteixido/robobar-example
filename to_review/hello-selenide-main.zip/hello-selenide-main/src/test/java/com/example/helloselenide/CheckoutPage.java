package com.example.helloselenide;

import com.codeborne.selenide.SelenideElement;

import static com.codeborne.selenide.Selenide.*;

// http://localhost:3000/#!/review
public class CheckoutPage {

    public SelenideElement btnButton = $(".btn-success");

    public SelenideElement ageInput = $("#ageInput" );


    public void order(){
        btnButton.click();
    }

    public void age(String value){
        ageInput.sendKeys(value);
    }




}